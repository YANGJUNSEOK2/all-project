/******************************************************************
Copyright (C) 2021 DigiPen Institute of Technology.
Reproduction or disclosure of this file or its contents without the prior
written consent of DigiPen Institute of Technology is prohibited.

File Name: LargestSubset.h
Project: Lab 3 - Recurssion
Author: 
Creation date: 
******************************************************************/
#pragma once

int FindLargestSubset(int* values, int count);