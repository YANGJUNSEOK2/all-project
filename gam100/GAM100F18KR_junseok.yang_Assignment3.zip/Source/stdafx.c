/******************************************************************************
filename    stdafx.c
author      junseok.yang
DP email    wnstjryang@gmail.com
course      GAM100 ** Do not use this code in your team project

Brief Description:
This file includes just the standard includes.
GAM100Project.pch will be the pre-compiled header
stdafx.obj will contain the pre-compiled type informati

******************************************************************************/
#include "stdafx.h"

/* NOTE: there must be at least one empty line after the #include, or the compiler gets confused */