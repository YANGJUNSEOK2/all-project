/******************************************************************************
Copyright (C) 2019 DigiPen Institute of Technology.
Reproduction or disclosure of this file or its contents without the prior
written consent of DigiPen Institute of Technology is prohibited.
Author:junseok.yang
Creation Date:Spring 2019.3.25
cs170 lab3
******************************************************************************/
#include "Fibonacci.h"
#include <cstdlib>


int main()
        {
            CS170::Lap2::Fibonacci(46);
            system("pause");
            return 0;
        }
   