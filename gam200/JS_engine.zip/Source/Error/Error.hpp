
#pragma once

#include<string>

namespace JS_Engine {
    namespace ErrorSystem {
        extern void FatalError(std::string p_errorString);
    }
}