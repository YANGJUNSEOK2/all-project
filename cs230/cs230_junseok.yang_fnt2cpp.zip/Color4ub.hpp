/*
 * Rudy Castan
 * Graphics Library
 * CS230
 */
#pragma once

namespace CS230
{
    class Color4ub
    {
    public:
        using unsigned_byte = unsigned char;

        unsigned_byte red   = 0;
        unsigned_byte green = 0;
        unsigned_byte blue  = 0;
        unsigned_byte alpha = 255;

    public:
      

    };
}
