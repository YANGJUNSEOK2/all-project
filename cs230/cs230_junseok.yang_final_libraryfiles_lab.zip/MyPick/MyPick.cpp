/*------------------------------------------------------------------------
Copyright (C) 2019 DigiPen Institute of Technology.
Reproduction or disclosure of this file or its contents without the prior
written consent of DigiPen Institute of Technology is prohibited.
Project:lab1
CourseNumber:cs230
Author:junseok.yang
Created:Spring 2019/3/22
------------------------------------------------------------------------*/
// MyPick.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <MadLib.h>
#include <iostream>

int main()
{
	std::cout << generate_madlib("gogogo", "foo bar", "computer");
	std::cout << "\n";

	//GetProcAddress()

	return 0;
}
